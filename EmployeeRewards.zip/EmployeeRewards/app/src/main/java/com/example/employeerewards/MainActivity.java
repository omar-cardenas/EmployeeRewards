package com.example.employeerewards;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.loginButton);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText userText = findViewById(R.id.editTextText);
                EditText passText = findViewById(R.id.editTextTextPassword);
                String user = userText.getText().toString();
                String pass = passText.getText().toString();



                //network connection
                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                String url = "http://10.0.2.2:8080/loginServlet/login?user=" + user + "&pass=" + pass;

                //retrieve data from query
                StringRequest req = new StringRequest(StringRequest.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {
                        String data = s.trim();
                        //Toast.makeText(MainActivity.this, "In Response", Toast.LENGTH_LONG).show();

                        if (!data.equals("")) {
                            String[] arr = data.split(":");
                            Toast.makeText(MainActivity.this, "success", Toast.LENGTH_LONG).show();

                            //make intent object to pass data to other activities
                            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                            String userId = arr[1];
                            String username = arr[0].split(" ")[2];
                            intent.putExtra("id", userId);
                            intent.putExtra("user", username);
                            startActivity(intent);
                        } else {
                            Toast.makeText(MainActivity.this, "Invalid User", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        volleyError.printStackTrace();
                    }

                });
                queue.add(req);



            }
        });

    }
}