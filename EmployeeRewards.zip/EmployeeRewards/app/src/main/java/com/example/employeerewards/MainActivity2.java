package com.example.employeerewards;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        //Make java objects for each UI button
        TextView welcomeView = findViewById(R.id.welcomeView);
        ImageView userPic = findViewById(R.id.userView);
        Button registrationsButton = findViewById(R.id.registrationsButton);
        Button awardsButton = findViewById(R.id.awardsButton);
        Button exitButton = findViewById(R.id.exitButton);
        Intent prevIntent = getIntent();
        String userId = prevIntent.getStringExtra("id");
        String username = prevIntent.getStringExtra("user");
        String welcomeMessage = "Welcome Back\n" + username;
        welcomeView.setText(welcomeMessage);
        ArrayList<String> arr = new ArrayList<>();


        //Shows user their registration history
        registrationsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerIntent = new Intent(MainActivity2.this, Registrations.class);
                registerIntent.putExtra("id", userId);
                startActivity(registerIntent);

            }
        });

        //Shows user all the awards currently available, each award has a point cost
        awardsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Intent awardIntent = new Intent(MainActivity2.this, Awards.class);
                    awardIntent.putExtra("id", userId);
                    startActivity(awardIntent);
            }
        });

        //Take user back to login screen
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //exit, go back to login screen
                finish();
                System.exit(0);
            }
        });

    }
}