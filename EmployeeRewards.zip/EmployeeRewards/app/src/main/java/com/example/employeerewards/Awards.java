package com.example.employeerewards;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;

public class Awards extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_awards);
        //Make java objects for each ui element
        Spinner spinner = findViewById(R.id.spinner);
        TextView awardView = findViewById(R.id.awardView);
        Button backButton = findViewById(R.id.back2);
        Button claimButton = findViewById(R.id.claimButton);
        TextView pointsView = findViewById(R.id.pointsView2);
        //For award descriptions
        StringBuilder sb = new StringBuilder();
        //For Spinner component
        ArrayList<String> awards = new ArrayList<>();
        ArrayList<String> allData = new ArrayList<>();
        ArrayList<String> storePoints = new ArrayList<>();

        Intent prevIntent = getIntent();

        //network connection
        RequestQueue pointsQueue = Volley.newRequestQueue(Awards.this);
        String pointsurl = "http://10.0.2.2:8080/loginServlet/GetPoints.jsp?empid=" +prevIntent.getStringExtra("id");

        //retrieve points employee has acquired from registrations made
        StringRequest req = new StringRequest(StringRequest.Method.GET, pointsurl, new Response.Listener<String>() {

            @Override
            public void onResponse(String s) {
                String points = s.trim();
                String pointsText = "Point Balance: " + points;
                pointsView.setText(pointsText);
                storePoints.add(points);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Toast.makeText(Awards.this, "Something went wrong", Toast.LENGTH_SHORT).show();
            }
        });

        pointsQueue.add(req);

        //network connection
        RequestQueue queue = Volley.newRequestQueue(Awards.this);
        String url = "http://10.0.2.2:8080/loginServlet/Awards.jsp";

        //retrieve all current awards
        StringRequest request = new StringRequest(StringRequest.Method.GET, url, new Response.Listener<String>(){
            public void onResponse(String s){

                String qData = s.trim();
                String[] rows = qData.split("#");


                //populate list with award names
                for(int i = 0; i<rows.length; i++){
                    allData.add(rows[i]);
                    String[] cols = rows[i].split(",");
                    awards.add(cols[0]);
                }
                //create adapter for spinner to hold all elements of the awards list
                ArrayAdapter<String> adapter = new ArrayAdapter<>(Awards.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, awards);
                spinner.setAdapter(adapter);

            }

        },null);

        queue.add(request);
        //populate spinner with each award name
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                awardView.clearComposingText();
                sb.setLength(0);
                // i=1=id, 2=cost, 4=exp date
                int selectedItem = position;
                String award = allData.get(position);
                String[] cols = award.split(",");
                String st1 = "Required Points: " + cols[2] + "\n";
                sb.append(st1);
                String st2 = "Name: " + cols[0] + "\n";
                String st3 = "Description:\n " + cols[3] + "\n";
                sb.append(st2);
                sb.append(st3);


                awardView.setText(sb.toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        //for award retrieval
        claimButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //check points
                //String p = prevIntent.getStringExtra("points");
                String p = storePoints.get(0);
                Integer points = Integer.parseInt(p);

                //adjust points
                String awardClaimed = allData.get(spinner.getSelectedItemPosition());
                String c = awardClaimed.split(",")[2];
                Integer cost = Integer.parseInt(c);
                if(points >= cost ) {
                    //String awardID = awardClaimed.split(",")[1];
                    points = points - cost;
                    String display = Integer.toString(points);
                    pointsView.setText(display);
                    Toast.makeText(Awards.this, "Code will be emailed to you within 24hrs", Toast.LENGTH_LONG).show();

                    //update points in DB
                    String id = prevIntent.getStringExtra("id");
                    RequestQueue updateQueue = Volley.newRequestQueue(Awards.this);
                    String url = "http://10.0.2.2:8080/loginServlet/updatePoints.jsp?newPoints=" + display + "&id=" + id + "&points=" + p;
                    StringRequest updateRequest = new StringRequest(StringRequest.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String s) {
                            Toast.makeText(Awards.this, s.trim(), Toast.LENGTH_SHORT).show();
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError volleyError) {
                            Toast.makeText(Awards.this, "Update Failed", Toast.LENGTH_SHORT).show();

                        }
                    });
                    updateQueue.add(updateRequest);

                }else {
                    Toast.makeText(Awards.this, "Insufficient Points", Toast.LENGTH_SHORT).show();
                }


            }
        });


        //Go back to user's main screen
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}