package com.example.employeerewards;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class Registrations extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrations);

        TextView historyView = findViewById(R.id.historyView);
        Button backButton = findViewById(R.id.back1);

        Intent prevI = getIntent();
        String userId = prevI.getStringExtra("id");

        //network connection
        RequestQueue queue = Volley.newRequestQueue(Registrations.this);
        String url = "http://10.0.2.2:8080/loginServlet/ShowRegistrations.jsp?id="+userId;

        StringBuilder sb = new StringBuilder();


        //retrieve data from query
        StringRequest request = new StringRequest(StringRequest.Method.GET, url, new Response.Listener<String>(){
            public void onResponse(String s){
                String qData = s.trim();
                String[] rows = qData.split("#");


                StringBuilder sb = new StringBuilder();
                String colNames = String.format("%s                 %s", "Date:", "Customer Email:\n");
                sb.append(colNames);
                for(int i = 0; i< rows.length; i++){
                    String[] cols = rows[i].split(",");
                    String registration = String.format("%s     %s\n", cols[2], cols[3]);
                    sb.append(registration);
                }
                historyView.setText(sb.toString());



            }

        },null);

        queue.add(request);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}